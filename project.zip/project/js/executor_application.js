document.addEventListener('DOMContentLoaded', () => {
	const user = JSON.parse(localStorage.getItem('current-user'));
	const applicationsContainer = document.querySelector('.container-applications');

	function loadApplications() {
			fetch(`http://localhost:3000/executor_applications/${user.email}`)
					.then(response => response.json())
					.then(data => {
							console.log('Applications data:', data); // Для отладки
							applicationsContainer.innerHTML = '';
							data.forEach(application => {
									const colorClass = getCleaningTypeClass(application.cleaning_type);
									const applicationHtml = `
											<div class="card-application ${colorClass}">
													<div class="name-application"><h3>${application.cleaning_type}</h3></div>
													<div class="list-application">
															<h4>Заказчик</h4>
															<span>${application.customer_email}</span>
															<h4>Провести уборку в:</h4>
															<span>${application.location}</span>
															<h4>Моющие средства и инструмент:</h4>
															<span>${application.supplies}</span>
															<h4>Дополнительный комментарий:</h4>
															<span>${application.comments}</span>
													</div>
													<div class="price-application">
															<h4>За</h4>
															<span>${application.price}</span>
													</div>
													<button class="dit-btn ex-btn" data-id="${application.id}">Откликнуться</button>
											</div>
									`;
									applicationsContainer.innerHTML += applicationHtml;
							});
							addRespondListeners();
					})
					.catch(error => console.error('Error loading applications:', error));
	}

	function addRespondListeners() {
			const respondButtons = document.querySelectorAll('.dit-btn.ex-btn');
			respondButtons.forEach(button => {
					button.addEventListener('click', () => {
							const applicationId = button.getAttribute('data-id');
							respondToApplication(applicationId);
					});
			});
	}

	function respondToApplication(applicationId) {
			fetch(`http://localhost:3000/application/${applicationId}/respond`, {
					method: 'POST',
					headers: {
							'Content-Type': 'application/json'
					},
					body: JSON.stringify({ specialist_email: user.email })
			})
			.then(response => response.json())
			.then(data => {
					alert('Вы успешно откликнулись на заявку');
					loadApplications();
			})
			.catch(error => console.error('Ошибка отклика на заявку:', error));
	}

	function getCleaningTypeClass(cleaningType) {
		switch (cleaningType) {
			case 'Химчистка': return 'dry-cleaning';
			case 'Уборка': return 'room-cleaning';
			case 'Мойка окон': return 'window-cleaning';
			case 'Генеральная уборка': return 'spring-cleaning';
			case 'Другое': return 'cleaning-renovation';
			case 'Ежедневная уборка': return 'daily-cleaning';
			default: return '';
		}
	}

	loadApplications();
});
