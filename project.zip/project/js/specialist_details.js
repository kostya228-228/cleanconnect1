document.addEventListener('DOMContentLoaded', () => {
	const urlParams = new URLSearchParams(window.location.search);
	const specialistId = urlParams.get('id');
	const specialistDetailsContainer = document.getElementById('specialist-details');

	console.log("Specialist ID:", specialistId);

	function loadSpecialistDetails(id) {
			fetch(`http://localhost:3000/specialist/${id}`)
					.then(response => response.json())
					.then(data => {
							console.log("Specialist Data:", data);
							
							if (!data) {
									specialistDetailsContainer.innerHTML = '<p>Ошибка: данные специалиста не найдены.</p>';
									return;
							}

							const colorClass = getCleaningTypeClass(data.cleaning_type || '');
							const detailsHtml = `
									<h2>Специалисты</h2>
									<div class="user-info-client-ditails">
											<div class="img-email">
													<div class="img-user">
															<div class="add-img"><img src="images/add2.png" alt="add" draggable="false"></div>
													</div>
													<span>${data.email || 'N/A'}</span>
											</div>
											<div class="completed-applications">
													<h3>${data.completedApplications || 0}</h3>
													<span>Выполненных заявок</span>
											</div>
									</div>
									<div class="inform-card ${colorClass}">
											<ol>
													<div style="display: flex; justify-content: space-between;">
															<li class="underline">${data.name || 'N/A'}</li>
															<li class="underline">${data.phone || 'N/A'}</li>
													</div>
													<li>
															<p class="underline"><span>${data.about || ''}</span></p>
													</li>
													<li><span class="bold">Специалист по:</span>
															<div>
																	<div class="marker-inform-card"></div><span class="underline">${data.cleaning_type || 'N/A'}</span>
															</div>
													</li>
											</ol>
											<div class="img-inform-card"><img src="images/card-services${getCleaningTypeImage(data.cleaning_type || '')}.png" alt=""></div>
									</div>
									<div class="dit-btn-container">
											<button class="dit-btn">Предложить работу</button>
									</div>
							`;
							specialistDetailsContainer.innerHTML = detailsHtml;
							
							const offerButton = document.querySelector('.dit-btn');
							offerButton.addEventListener('click', () => {
									const user = JSON.parse(localStorage.getItem('current-user'));
									if (user) {
											fetch(`http://localhost:3000/specialist/${specialistId}/offer`, {
													method: 'POST',
													headers: {
															'Content-Type': 'application/json'
													},
													body: JSON.stringify({
															customer_email: user.email,
															customer_name: user.name,
															customer_phone: user.phone,
															cleaning_type: data.cleaning_type,
															specialist_name: data.email
													})
											})
													.then(response => response.json())
													.then(data => {
															alert('Предложение успешно отправлено');
													})
													.catch(error => console.error('Error sending offer:', error));
									}
							});
					})
					.catch(error => console.error('Error loading specialist details:', error));
	}

	function getCleaningTypeClass(cleaningType) {
			switch (cleaningType) {
					case 'Химчистка': return 'dry-cleaning';
					case 'Уборка комнаты': return 'room-cleaning';
					case 'Мойка окон': return 'window-cleaning';
					case 'Генеральная уборка': return 'deep-cleaning';
					case 'Уборка после ремонта': return 'post-renovation-cleaning';
					case 'Ежедневная уборка': return 'daily-cleaning';
					default: return '';
			}
	}

	function getCleaningTypeImage(cleaningType) {
			switch (cleaningType) {
					case 'Химчистка': return '3';
					case 'Уборка комнаты': return '2';
					case 'Мойка окон': return '6';
					case 'Генеральная уборка': return '5';
					case 'Уборка после ремонта': return '1';
					case 'Ежедневная уборка': return '4';
					default: return '1';
			}
	}

	if (specialistId) {
			loadSpecialistDetails(specialistId);
	} else {
			specialistDetailsContainer.innerHTML = '<p>Ошибка: ID специалиста не указан.</p>';
	}
});
