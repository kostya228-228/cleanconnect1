function processParagraphs() {
	const paragraphs = document.querySelectorAll('.underline');

	paragraphs.forEach(element => {
		const maxChars = calculateMaxChars();
		const text = element.textContent;
		const words = text.split(' ');
		let line = '';
		element.innerHTML = '';

		words.forEach(word => {
			if ((line + word).length <= maxChars) {
				line += word + ' ';
			} else {
				if (line.trim()) {
					const span = document.createElement('span');
					span.textContent = line.trim();
					element.appendChild(span);
				}
				line = word + ' ';
			}
		});

		if (line.trim()) {
			const span = document.createElement('span');
			span.textContent = line.trim();
			element.appendChild(span);
		}
	});
}

function calculateMaxChars() {
	const width = window.innerWidth;
	if (width > 1900) return 90;
	if (width > 1500) return 70;
	if (width > 1000) return 60;
	if (width > 900) return 20;
	return 20;
}

processParagraphs();

window.addEventListener('resize', processParagraphs);



// auth
const btnCustomer = document.getElementById('btn-customer');
const btnExecutor = document.getElementById('btn-executor');
const authContainer = document.getElementById('auth-container');
const authSelect = document.getElementById('auth-select');
const registerContainer = document.getElementById('register-container');
const btnRegister = document.getElementById('btn-register');
const registerBtn = document.getElementById('register-btn');
const loginBtn = document.getElementById('login-btn');
const btnBackAuth = document.getElementById('btn-back-auth');
const btnBackRegister = document.getElementById('btn-back-register');
const registerErrorMessage = document.getElementById('register-error-message');
const loginErrorMessage = document.getElementById('login-error-message');

function setProfession(profession) {
    localStorage.setItem('profession', profession);
    authSelect.classList.add('hide');
    authContainer.classList.remove('hide');
}

function showRegisterForm() {
    authContainer.classList.add('hide');
    registerContainer.classList.remove('hide');
}

function showAuthSelect() {
    authContainer.classList.add('hide');
    registerContainer.classList.add('hide');
    authSelect.classList.remove('hide');
}

function showAuthForm() {
    registerContainer.classList.add('hide');
    authContainer.classList.remove('hide');
}

async function registerUser() {
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    const profession = localStorage.getItem('profession');

    try {
        const response = await fetch('http://localhost:3000/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password, profession })
        });

        const result = await response.json();

        if (response.ok) {
            alert('Регистрация успешна');
            document.getElementById('register-email').value = '';
            document.getElementById('register-password').value = '';
            registerErrorMessage.textContent = '';
            showAuthForm();
        } else {
            registerErrorMessage.textContent = result.error;
        }
    } catch (error) {
        registerErrorMessage.textContent = 'Ошибка сети';
    }
}

async function loginUser() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const profession = localStorage.getItem('profession');

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password, profession })
        });

        const result = await response.json();

        if (response.ok) {
            localStorage.setItem('current-user', JSON.stringify({ email, profession }));
            if (result.profession === 'заказчик') {
                window.location.href = 'index.html';
            } else if (result.profession === 'исполнитель') {
                window.location.href = 'executor.html';
            }
        } else {
            loginErrorMessage.textContent = result.error;
        }
    } catch (error) {
        loginErrorMessage.textContent = 'Ошибка сети';
    }
}

btnCustomer.addEventListener('click', () => setProfession('заказчик'));
btnExecutor.addEventListener('click', () => setProfession('исполнитель'));
btnRegister.addEventListener('click', showRegisterForm);
registerBtn.addEventListener('click', registerUser);
loginBtn.addEventListener('click', loginUser);
btnBackAuth.addEventListener('click', showAuthSelect);
btnBackRegister.addEventListener('click', showAuthForm);


