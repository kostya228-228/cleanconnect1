document.addEventListener('DOMContentLoaded', () => {
	const specialistsContainer = document.getElementById('specialists-container');
	const searchInput = document.getElementById('search-input');
	const searchBtn = document.getElementById('search-btn');

	function createSpecialistCard(specialist) {
			const card = document.createElement('div');
			card.classList.add('card-specialists');
			card.innerHTML = `
					<img src="https://fagligsenior.dk/wp-content/uploads/2020/03/brug.rengoerng.istock-518398901.jpg" alt="">
					<div class="name-card-specialists-${getCleaningTypeClass(specialist.cleaning_type)}">
							<h3>${specialist.cleaning_type}</h3>
							<img src="./images/card-services${getCleaningTypeImage(specialist.cleaning_type)}.png" alt="">
					</div>
					<div class="description-card-specialists">
							<span>${specialist.email}</span>
							<span>${specialist.name}</span>
							<span>${specialist.phone}</span>
							<a href="сlient_details.html?id=${specialist.id}">Подробнее</a>
					</div>
			`;
			return card;
	}

	function getCleaningTypeClass(cleaningType) {
			switch (cleaningType) {
					case 'Химчистка': return 'blue';
					case 'Уборка комнаты': return 'green';
					case 'Мойка окон': return 'purple';
					case 'Генеральная уборка': return 'yellow';
					case 'Уборка после ремонта': return 'orange';
					case 'Ежедневная уборка': return 'azure';
					default: return '';
			}
	}

	function getCleaningTypeImage(cleaningType) {
			switch (cleaningType) {
					case 'Химчистка': return '3';
					case 'Уборка комнаты': return '2';
					case 'Мойка окон': return '6';
					case 'Генеральная уборка': return '5';
					case 'Уборка после ремонта': return '1';
					case 'Ежедневная уборка': return '4';
					default: return '1';
			}
	}

	function loadSpecialists(query = '') {
			fetch(`http://localhost:3000/specialists?query=${query}`)
					.then(response => response.json())
					.then(data => {
							specialistsContainer.innerHTML = '';
							data.forEach(specialist => {
									const card = createSpecialistCard(specialist);
									specialistsContainer.appendChild(card);
							});
					})
					.catch(error => console.error('Error loading specialists:', error));
	}

	searchBtn.addEventListener('click', () => {
			const query = searchInput.value;
			loadSpecialists(query);
	});

	loadSpecialists();
});
