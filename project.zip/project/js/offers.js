document.addEventListener('DOMContentLoaded', () => {
	const user = JSON.parse(localStorage.getItem('current-user'));
	const offersContainer = document.getElementById('offers-container');
	const offersCount = document.getElementById('offers-count');

	function loadOffers() {
			fetch(`http://localhost:3000/specialist/${user.email}/offers`)
					.then(response => response.json())
					.then(data => {
							offersContainer.innerHTML = '';
							data.forEach(offer => {
									const colorClass = getCleaningTypeClass(offer.cleaning_type);
									const offerHtml = `
											<div class="card-application ${colorClass}">
													<div class="name-application"><h3>${offer.cleaning_type}</h3></div>
													<div class="list-application">
															<h4>Заказчик</h4>
															<span>${offer.customer_email}</span>
															<h4>Имя</h4>
															<span>${offer.customer_name}</span>
															<h4>Телефон</h4>
															<span>${offer.customer_phone}</span>
													</div>
													<div class="btns-offset">
															<button class="delete-btn" data-id="${offer.id}">Удалить</button>
															<button class="dit-btn" data-id="${offer.id}">Откликнуться</button>
													</div>
											</div>
									`;
									offersContainer.innerHTML += offerHtml;
							});

							document.querySelectorAll('.delete-btn').forEach(button => {
									button.addEventListener('click', (event) => {
											const offerId = event.target.getAttribute('data-id');
											deleteOffer(offerId);
									});
							});

							document.querySelectorAll('.dit-btn').forEach(button => {
									button.addEventListener('click', (event) => {
											const offerId = event.target.getAttribute('data-id');
											respondToOffer(offerId);
									});
							});

							offersCount.textContent = data.length;
					})
					.catch(error => console.error('Error loading offers:', error));
	}

	function getCleaningTypeClass(cleaningType) {
			switch (cleaningType) {
					case 'Химчистка': return 'dry-cleaning';
					case 'Уборка комнаты': return 'room-cleaning';
					case 'Мойка окон': return 'window-cleaning';
					case 'Генеральная уборка': return 'spring-cleaning';
					case 'Уборка после ремонта': return 'post-renovation-cleaning';
					case 'Ежедневная уборка': return 'daily';
					default: return '';
			}
	}

	function deleteOffer(offerId) {
			fetch(`http://localhost:3000/offer/${offerId}`, {
					method: 'DELETE'
			})
					.then(response => response.json())
					.then(data => {
							alert(data.message);
							loadOffers();
					})
					.catch(error => console.error('Error deleting offer:', error));
	}

	function respondToOffer(offerId) {
			fetch(`http://localhost:3000/offer/${offerId}/respond`, {
					method: 'DELETE'
			})
					.then(response => response.json())
					.then(data => {
							alert(data.message);
							loadOffers();
					})
					.catch(error => console.error('Error responding to offer:', error));
	}

	loadOffers();
});
