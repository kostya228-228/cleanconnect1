document.addEventListener('DOMContentLoaded', () => {
	const publishButton = document.querySelector('.btn-place');
	const user = JSON.parse(localStorage.getItem('current-user'));

	publishButton.addEventListener('click', () => {
		const cleaningType = document.querySelector('input[name="cleaning_type"]:checked');
		const location = document.querySelector('input[name="location"]:checked');
		const supplies = document.querySelector('input[name="supplies"]:checked');
		const price = document.querySelector('input[name="price"]').value;
		const comments = document.querySelector('textarea[name="comments"]').value;

		if (!cleaningType || !location || !supplies || !price || !comments) {
			alert('Пожалуйста, заполните все поля');
			return;
		}

		const applicationData = {
			customer_email: user.email,
			cleaning_type: cleaningType.nextElementSibling.innerText,
			location: location.nextElementSibling.innerText,
			supplies: supplies.nextElementSibling.innerText,
			price,
			comments
		};

		fetch('http://localhost:3000/place_application', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(applicationData)
		})
			.then(response => response.json())
			.then(data => {
				alert(data.message);
			})
			.catch(error => console.error('Error placing application:', error));
	});
});
