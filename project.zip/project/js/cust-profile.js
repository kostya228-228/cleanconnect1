document.addEventListener('DOMContentLoaded', () => {
	const user = JSON.parse(localStorage.getItem('current-user'));
	if (user) {
			document.getElementById('user-email').textContent = user.email;

			fetch(`http://localhost:3000/profile/${user.email}`)
					.then(response => {
							if (!response.ok) {
									throw new Error('Network response was not ok');
							}
							return response.json();
					})
					.then(data => {
							if (data.phone) {
									document.getElementById('phone-input').value = data.phone;
							}
							document.getElementById('total-applications').textContent = data.totalApplications;
							document.getElementById('active-applications').textContent = data.activeApplications;
							document.getElementById('completed-applications').textContent = data.completedApplications;
					})
					.catch(error => console.error('Error fetching profile data:', error));
	}

	document.getElementById('save-btn').addEventListener('click', () => {
			const phone = document.getElementById('phone-input').value;
			fetch(`http://localhost:3000/profile/${user.email}`, {
					method: 'POST',
					headers: {
							'Content-Type': 'application/json'
					},
					body: JSON.stringify({ phone })
			})
			.then(response => {
					if (!response.ok) {
							throw new Error('Network response was not ok');
					}
					return response.json();
			})
			.then(data => {
					alert('Данные сохранены успешно');
			})
			.catch(error => console.error('Error saving profile data:', error));
	});
});
