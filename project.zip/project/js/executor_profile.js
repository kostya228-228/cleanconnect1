document.addEventListener('DOMContentLoaded', () => {
	// Получаем все радио-кнопки
	const radioButtons = document.querySelectorAll('input[name="cleaning_type"]');
	// Получаем контейнер для карточки профиля
	const cardContainer = document.querySelector("#card-ex-prof");

	// Добавляем обработчик события change к каждой радио-кнопке
	radioButtons.forEach(radioButton => {
		radioButton.addEventListener('change', function () {
			// Проверяем, какая радио-кнопка выбрана
			if (this.checked) {
				const selectedCleaningType = this.value;
				// Удаляем все классы у контейнера
				cardContainer.classList.remove('dry-cleaning', 'window-cleaning', 'daily-cleaning', 'deep-cleaning', 'post-renovation-cleaning');
				// Добавляем класс в зависимости от выбранного типа уборки
				switch (selectedCleaningType) {
					case 'Химчистка':
						cardContainer.classList.add('dry-cleaning');
						break;
					case 'Мойка окон':
						cardContainer.classList.add('window-cleaning');
						break;
					case 'Ежедневная уборка':
						cardContainer.classList.add('daily-cleaning');
						break;
					case 'Генеральная уборка':
						cardContainer.classList.add('deep-cleaning');
						break;
					case 'Уборка после ремонта':
						cardContainer.classList.add('post-renovation-cleaning');
						break;
					default:
						console.error("Неизвестный тип уборки:", selectedCleaningType);
				}
			}
		});
	});

	const user = JSON.parse(localStorage.getItem('current-user'));
	if (user) {
		document.getElementById('user-email').textContent = user.email;

		fetch(`http://localhost:3000/executor_profile/${user.email}`)
			.then(response => {
				if (!response.ok) {
					throw new Error('Network response was not ok');
				}
				return response.json();
			})
			.then(data => {
				if (data.phone) {
					document.getElementById('phone-input').value = data.phone;
				}
				if (data.name) {
					document.getElementById('executor-name').value = data.name;
				}
				if (data.about) {
					document.getElementById('about-me').value = data.about;
				}
				if (data.cleaning_type) {
					document.querySelector(`input[name="cleaning_type"][value="${data.cleaning_type}"]`).checked = true;
					// Триггерим событие change для установки класса
					const event = new Event('change');
					document.querySelector(`input[name="cleaning_type"][value="${data.cleaning_type}"]`).dispatchEvent(event);
				}
				document.getElementById('active-applications').textContent = data.activeApplications;
				document.getElementById('completed-applications').textContent = data.completedApplications;
			})
			.catch(error => console.error('Error fetching profile data:', error));
	}

	document.getElementById('save-btn').addEventListener('click', () => {
		const name = document.getElementById('executor-name').value;
		const phone = document.getElementById('phone-input').value;
		const about = document.getElementById('about-me').value;
		const cleaningType = document.querySelector('input[name="cleaning_type"]:checked').value;

		fetch(`http://localhost:3000/executor_profile/${user.email}`, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({ name, phone, about, cleaning_type: cleaningType })
		})
			.then(response => {
				if (!response.ok) {
					throw new Error('Network response was not ok');
				}
				return response.json();
			})
			.then(data => {
				alert('Данные сохранены успешно');
			})
			.catch(error => console.error('Error saving profile data:', error));
	});
});
