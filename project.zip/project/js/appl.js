document.addEventListener('DOMContentLoaded', () => {
	const user = JSON.parse(localStorage.getItem('current-user'));
	const applicationsContainer = document.getElementById('applications-container');
	const otklikContainer = document.getElementById('otklik-container');

	function loadApplications() {
		fetch(`http://localhost:3000/applications/${user.email}`)
			.then(response => response.json())
			.then(data => {
				applicationsContainer.innerHTML = '';
				data.forEach(application => {
					const colorClass = getCleaningTypeClass(application.cleaning_type);
					const applicationHtml = `
											<div class="card-application ${colorClass}">
													<div class="name-application"><h3>${application.cleaning_type}</h3></div>
													<div class="list-application">
															<h4>Заказчик</h4>
															<span>${application.customer_email}</span>
															<h4>Провести уборку в:</h4>
															<span>${application.location}</span>
															<h4>Моющие средства и инструмент:</h4>
															<span>${application.supplies}</span>
															<h4>Дополнительный комментарий:</h4>
															<span>${application.comments}</span>
													</div>
													<div class="price-application">
															<h4>Ваша цена</h4>
															<span>${application.price}</span>
													</div>
													<button class="edit-application delete-application" data-id="${application.id}">Удалить</button>
											</div>
									`;
					applicationsContainer.innerHTML += applicationHtml;
				});

				document.querySelectorAll('.delete-application').forEach(button => {
					button.addEventListener('click', () => {
						const applicationId = button.getAttribute('data-id');
						fetch(`http://localhost:3000/applications/${applicationId}`, {
							method: 'DELETE'
						})
							.then(response => response.json())
							.then(data => {
								alert(data.message);
								loadApplications();
							})
							.catch(error => console.error('Ошибка удаления заявки:', error));
					});
				});
			})
			.catch(error => console.error('Ошибка загрузки заявок:', error));
	}

	function loadResponses() {
		fetch(`http://localhost:3000/executor_appl/${user.email}`)
			.then(response => response.json())
			.then(data => {
				otklikContainer.innerHTML = '';
				data.forEach(application => {
					const colorClass = getCleaningTypeClass(application.cleaning_type);
					const responseHtml = `
											<div class="card-application ${colorClass}">
													<div class="name-application"><h3>${application.cleaning_type}</h3></div>
													<div class="list-application">
															<h4>Заказчик</h4>
															<span>${application.customer_email}</span>
															<h4>Провести уборку в:</h4>
															<span>${application.location}</span>
															<h4>Моющие средства и инструмент:</h4>
															<span>${application.supplies}</span>
															<h4>Дополнительный комментарий:</h4>
															<span>${application.comments}</span>
													</div>
													<div class="price-application">
															<h4>Ваша цена</h4>
															<span>${application.price}</span>
													</div>
													<button class="edit-application complete-application" data-id="${application.id}">Завершить</button>
											</div>
									`;
					otklikContainer.innerHTML += responseHtml;
				});

				document.querySelectorAll('.complete-application').forEach(button => {
					button.addEventListener('click', () => {
						const applicationId = button.getAttribute('data-id');
						fetch(`http://localhost:3000/application/${applicationId}/complete`, {
							method: 'POST'
						})
							.then(response => response.json())
							.then(data => {
								alert(data.message);
								loadResponses();
							})
							.catch(error => console.error('Ошибка завершения заявки:', error));
					});
				});
			})
			.catch(error => console.error('Ошибка загрузки откликов:', error));
	}

	function getCleaningTypeClass(cleaningType) {
		switch (cleaningType) {
			case 'Химчистка': return 'dry-cleaning';
			case 'Уборка': return 'room-cleaning';
			case 'Мойка окон': return 'window-cleaning';
			case 'Генеральная уборка': return 'spring-cleaning';
			case 'Другое': return 'cleaning-renovation';
			case 'Ежедневная уборка': return 'daily-cleaning';
			default: return '';
		}
	}

	loadApplications();
	loadResponses();
});
