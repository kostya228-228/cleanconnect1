const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');

const app = express();
const db = new sqlite3.Database('./database.db');

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname)));

db.serialize(() => {
	db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT, password TEXT, profession TEXT, phone TEXT, name TEXT, about TEXT, cleaning_type TEXT, UNIQUE(email, profession))");
	db.run("CREATE TABLE IF NOT EXISTS applications (id INTEGER PRIMARY KEY, customer_email TEXT, cleaning_type TEXT, location TEXT, supplies TEXT, price INTEGER, comments TEXT, status TEXT, executor_email TEXT)");
	db.run("CREATE TABLE IF NOT EXISTS offers (id INTEGER PRIMARY KEY, specialist_id INTEGER, customer_email TEXT, customer_name TEXT, customer_phone TEXT, cleaning_type TEXT, specialist_name TEXT, status TEXT, FOREIGN KEY(specialist_id) REFERENCES users(id))");
	db.run("CREATE TABLE IF NOT EXISTS responses (id INTEGER PRIMARY KEY, application_id INTEGER, specialist_email TEXT, customer_name TEXT, status TEXT, FOREIGN KEY(application_id) REFERENCES applications(id))");
});

app.post('/register', (req, res) => {
	const { email, password, profession } = req.body;

	if (password.length < 6) {
		return res.status(400).json({ error: 'Пароль должен быть не менее 6 символов' });
	}

	db.get("SELECT * FROM users WHERE email = ? AND profession = ?", [email, profession], (err, row) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		if (row) {
			return res.status(400).json({ error: 'Пользователь с таким email и ролью уже существует' });
		}

		db.run("INSERT INTO users (email, password, profession) VALUES (?, ?, ?)", [email, password, profession], function (err) {
			if (err) {
				return res.status(500).json({ error: 'Ошибка регистрации пользователя' });
			} else {
				res.status(200).json({ message: 'Пользователь успешно зарегистрирован' });
			}
		});
	});
});

app.post('/login', (req, res) => {
	const { email, password, profession } = req.body;

	db.get("SELECT * FROM users WHERE email = ? AND password = ? AND profession = ?", [email, password, profession], (err, row) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		if (!row) {
			return res.status(400).json({ error: 'Неверные учетные данные' });
		}

		res.status(200).json({ message: 'Вход успешен', profession: profession });
	});
});

app.get('/specialists', (req, res) => {
	const query = req.query.query || '';
	db.all("SELECT * FROM users WHERE profession = 'исполнитель' AND (name LIKE ? OR cleaning_type LIKE ?)", [`%${query}%`, `%${query}%`], (err, rows) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		res.status(200).json(rows);
	});
});

app.get('/specialist/:id', (req, res) => {
	const id = req.params.id;

	db.get("SELECT * FROM users WHERE id = ?", [id], (err, user) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		if (!user) {
			return res.status(404).json({ error: 'Специалист не найден' });
		}

		db.all("SELECT * FROM applications WHERE status = 'completed' AND executor_email = ?", [user.email], (err, applications) => {
			if (err) {
				return res.status(500).json({ error: 'Ошибка сервера' });
			}

			const completedApplications = applications.filter(app => app.status === 'completed').length;

			res.status(200).json({
				email: user.email,
				phone: user.phone,
				name: user.name,
				about: user.about,
				cleaning_type: user.cleaning_type,
				completedApplications
			});
		});
	});
});

app.get('/profile/:email', (req, res) => {
	const email = req.params.email;

	db.get("SELECT * FROM users WHERE email = ?", [email], (err, user) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		if (!user) {
			return res.status(404).json({ error: 'Пользователь не найден' });
		}

		db.all("SELECT * FROM applications WHERE customer_email = ?", [email], (err, applications) => {
			if (err) {
				return res.status(500).json({ error: 'Ошибка сервера' });
			}

			const totalApplications = applications.length;
			const activeApplications = applications.filter(app => app.status === 'active').length;
			const completedApplications = applications.filter(app => app.status === 'completed').length;

			res.status(200).json({
				email: user.email,
				phone: user.phone,
				totalApplications,
				activeApplications,
				completedApplications
			});
		});
	});
});

app.post('/profile/:email', (req, res) => {
	const email = req.params.email;
	const { phone } = req.body;

	db.run("UPDATE users SET phone = ? WHERE email = ?", [phone, email], function (err) {
		if (err) {
			return res.status(500).json({ error: 'Ошибка обновления профиля' });
		}
		res.status(200).json({ message: 'Профиль обновлен успешно' });
	});
});

app.get('/executor_profile/:email', (req, res) => {
	const email = req.params.email;

	db.get("SELECT * FROM users WHERE email = ?", [email], (err, user) => {
		if (err) {
			console.error('Ошибка запроса пользователя:', err);
			return res.status(500).json({ error: 'Ошибка сервера' });
		}
		if (!user) {
			return res.status(404).json({ error: 'Пользователь не найден' });
		}
		db.all("SELECT * FROM offers WHERE specialist_name = ?", [email], (err, responses) => {
			db.all("SELECT * FROM applications WHERE executor_email = ?", [email], (err, applications) => {
				if (err) {
					console.error('Ошибка запроса заявок:', err);
					return res.status(500).json({ error: 'Ошибка сервера' });
				}

				const activeApplications = responses.filter(app => app.status === 'active').length + applications.filter(app => app.status === 'active').length;
				const completedApplications = responses.filter(app => app.status === 'completed').length + applications.filter(app => app.status === 'completed').length;

				res.status(200).json({
					email: user.email,
					phone: user.phone,
					name: user.name,
					about: user.about,
					cleaning_type: user.cleaning_type,
					activeApplications,
					completedApplications
				});
			});
		})
	});
});


app.post('/executor_profile/:email', (req, res) => {
	const email = req.params.email;
	const { name, phone, about, cleaning_type } = req.body;

	db.run("UPDATE users SET name = ?, phone = ?, about = ?, cleaning_type = ? WHERE email = ?", [name, phone, about, cleaning_type, email], function (err) {
		if (err) {
			console.error('Ошибка обновления профиля:', err);
			return res.status(500).json({ error: 'Ошибка обновления профиля' });
		}
		res.status(200).json({ message: 'Профиль обновлен успешно' });
	});
});

app.post('/specialist/:id/offer', (req, res) => {
	const { customer_email, customer_name, customer_phone, cleaning_type, specialist_name } = req.body;
	const specialistId = req.params.id;

	db.get("SELECT phone, name FROM users WHERE email = ?", [customer_email], (err, user) => {
			if (err) {
					console.error('Ошибка получения данных пользователя:', err);
					return res.status(500).json({ error: 'Ошибка получения данных пользователя' });
			}
			if (!user) {
					console.error('Пользователь не найден');
					return res.status(404).json({ error: 'Пользователь не найден' });
			}

			db.run("INSERT INTO offers (specialist_id, customer_email, customer_name, customer_phone, cleaning_type, specialist_name) VALUES (?, ?, ?, ?, ?, ?)", 
					[specialistId, customer_email, customer_email, user.phone, cleaning_type, specialist_name], function (err) {
					if (err) {
							console.error('Ошибка отправки предложения:', err);
							return res.status(500).json({ error: 'Ошибка отправки предложения' });
					}

					db.get("SELECT id FROM applications WHERE customer_email = ? AND cleaning_type = ?", [customer_email, cleaning_type], function (err, application) {
							if (err) {
									console.error('Ошибка получения заявки:', err);
									return res.status(500).json({ error: 'Ошибка получения заявки' });
							}

							if (!application) {
									console.error('Заявка не найдена');
									return res.status(404).json({ error: 'Заявка не найдена' });
							}

							db.run("INSERT INTO responses (application_id, specialist_email, customer_name, status) VALUES (?, ?, ?, 'active')", 
									[application.id, specialist_name, user.name], function (err) {
									if (err) {
											console.error('Ошибка сохранения отклика:', err);
											return res.status(500).json({ error: 'Ошибка сохранения отклика' });
									}

									res.status(200).json({ message: 'Предложение и отклик успешно отправлены' });
							});
					});
			});
	});
});


app.delete('/offer/:id', (req, res) => {
	const offerId = req.params.id;

	db.run("DELETE FROM offers WHERE id = ?", [offerId], function (err) {
		if (err) {
			console.error('Ошибка удаления предложения:', err);
			return res.status(500).json({ error: 'Ошибка удаления предложения' });
		}
		res.status(200).json({ message: 'Предложение успешно удалено' });
	});
});

app.delete('/offer/:id/respond', (req, res) => {
	const offerId = req.params.id;

	db.run("DELETE FROM offers WHERE id = ?", [offerId], function (err) {
		if (err) {
			console.error('Ошибка удаления предложения:', err);
			return res.status(500).json({ error: 'Ошибка удаления предложения' });
		}
		res.status(200).json({ message: 'Вы откликнулись' });
	});
});

app.post('/application/:id/respond', (req, res) => {
	const applicationId = req.params.id;
	const specialistEmail = req.body.specialist_email;

	db.get("SELECT * FROM applications WHERE id = ?", [applicationId], (err, application) => {
		if (err) {
			console.error('Ошибка получения заявки:', err);
			return res.status(500).json({ error: 'Ошибка получения заявки' });
		}
		if (!application) {
			return res.status(404).json({ error: 'Заявка не найдена' });
		}

		db.run("UPDATE applications SET status = 'active', executor_email = ? WHERE id = ?", [specialistEmail, applicationId], function (err) {
			if (err) {
				console.error('Ошибка отклика на заявку:', err);
				return res.status(500).json({ error: 'Ошибка отклика на заявку' });
			}

			res.status(200).json({ message: 'Заявка успешно активирована' });
		});
	});
});

app.get('/specialist/:name/offers', (req, res) => {
	const specialistName = req.params.name;

	db.all("SELECT * FROM offers WHERE specialist_name = ?", [specialistName], (err, rows) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка получения предложений' });
		}
		res.status(200).json(rows);
	});
});

app.post('/place_application', (req, res) => {
	const { customer_email, cleaning_type, location, supplies, price, comments } = req.body;

	db.run("INSERT INTO applications (customer_email, cleaning_type, location, supplies, price, comments, status) VALUES (?, ?, ?, ?, ?, ?, 'active')", [customer_email, cleaning_type, location, supplies, price, comments], function (err) {
		if (err) {
			return res.status(500).json({ error: 'Ошибка размещения заявки' });
		}
		res.status(200).json({ message: 'Заявка успешно размещена' });
	});
});

app.get('/applications/:email', (req, res) => {
	const email = req.params.email;

	db.all("SELECT * FROM applications WHERE customer_email = ?", [email], (err, rows) => {
		if (err) {
			return res.status(500).json({ error: 'Ошибка получения заявок' });
		}
		res.status(200).json(rows);
	});
});

app.delete('/applications/:id', (req, res) => {
	const applicationId = req.params.id;

	db.run("DELETE FROM applications WHERE id = ?", [applicationId], function (err) {
		if (err) {
			return res.status(500).json({ error: 'Ошибка удаления заявки' });
		}

		db.run("DELETE FROM responses WHERE application_id = ?", [applicationId], function (err) {
			if (err) {
				return res.status(500).json({ error: 'Ошибка удаления отклика' });
			}

			res.status(200).json({ message: 'Заявка и отклик успешно удалены' });
		});
	});
});

app.get('/executor_applications/:email', (req, res) => {
	db.all("SELECT * FROM applications WHERE status = 'active' AND executor_email IS NULL", [], (err, rows) => {
		if (err) {
			console.error('Ошибка получения активных заявок:', err);
			return res.status(500).json({ error: 'Ошибка получения активных заявок' });
		}
		res.status(200).json(rows);
	});
});

app.get('/executor_appl/:email', (req, res) => {
	const email = req.params.email;

	db.all("SELECT * FROM applications WHERE status = 'active' AND customer_email = ? AND executor_email IS NOT NULL", [email], (err, rows) => {
		if (err) {
			console.error('Ошибка получения активных заявок:', err);
			return res.status(500).json({ error: 'Ошибка получения активных заявок' });
		}
		res.status(200).json(rows);
	});

});

app.post('/application/:id/complete', (req, res) => {
	const applicationId = req.params.id;

	db.run("UPDATE applications SET status = 'completed' WHERE id = ?", [applicationId], function (err) {
		if (err) {
			console.error('Ошибка завершения заявки:', err);
			return res.status(500).json({ error: 'Ошибка завершения заявки' });
		}

		res.status(200).json({ message: 'Заявка успешно завершена' });
	});
});



app.listen(3000, () => {
	console.log('Server is running on http://localhost:3000');
});
